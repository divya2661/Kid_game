package com.gojek.parkinglot

class InputHandler() {
	val parkLot = new ParkingLotDef

	def handler(args: Array[String]) {
		if(!args.isEmpty){
			args(0) match {
				case "create_parking_lot" => parkLot.createParkingLot(args(1).toInt)
				case "park"               => parkLot.park(args(1), args(2))
				case "leave"              => parkLot.leave(args(1).toInt)
				case "status"             => parkLot.status()
				case "registration_numbers_for_cars_with_colour" => parkLot.getRegistrationNumberFromColor(args(1))
				case "slot_numbers_for_cars_with_colour"         => parkLot.getSlotNoFromColor(args(1))
				case "slot_number_for_registration_number"       => parkLot.getSlotNoFromRegNo(args(1))
				case _ 											 => println("Invald input")
			}
		}
	}
}