package com.gojek.parkinglot

object LogCodes{
	final val NUM_SLOT_ERROR = "ERROR: Invalid slot count"
	final val NO_PARKING_LOT_ERROR = "Sorry, parking lot is not created"
	final val PARKING_LOT_FULL_ERROR = "Sorry, parking lot is full"
	final val PARKING_LOT_EMPTY_ERROR = "Parking lot is empty"
	final val PARKING_LOT_OUT_OF_BOUND = "Slot number is out of bound"	
}
