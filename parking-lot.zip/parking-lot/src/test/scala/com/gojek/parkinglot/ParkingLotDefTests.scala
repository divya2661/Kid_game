package com.gojek.parkinglot

import org.scalatest.FunSuite
import org.scalatest.BeforeAndAfter


class ParkingLotDefTests extends FunSuite with BeforeAndAfter {

	trait MockOutput extends Output {
		var messages: Seq[String] = Seq()
		override def println(s: String) = messages = messages :+ s
		override def print(s: String) = messages = messages :+ s
	}
	var parkLot: ParkingLotDef with MockOutput = _ 

	before {
		parkLot = new ParkingLotDef with MockOutput
	}
	
    test("create_Parking_lot function unit testing"){
    	parkLot.createParkingLot(6)
    	assert(parkLot.maxCount == 6)
    	assert(parkLot.slotCarMap.size == 0)
    	assert(parkLot.availParkingSLot.length == 7)
    	assert(parkLot.messages(0).toLowerCase contains "created parking lot with 6 slots")
    }

    test("park function unit testing"){
    	parkLot.park("KA-01-HH-1234","White")
    	assert(parkLot.messages(0).toLowerCase contains "sorry, parking lot is not created")
    	parkLot.createParkingLot(3)
    	parkLot.park("KA-01-HH-1234","White")
    	assert(parkLot.messages(2).toLowerCase contains "allocated slot number: 1")
    	parkLot.park("KA-01-HH-9999", "White")
    	assert(parkLot.messages(3).toLowerCase contains "allocated slot number: 2")
    	parkLot.park("KA-01-BB-0001", "Black")
    	assert(parkLot.messages(4).toLowerCase contains "allocated slot number: 3")
    	parkLot.park("KA-01-HH-2701", "Black")
    	assert(parkLot.messages(5).toLowerCase contains "sorry, parking lot is full")
    }

    test("leave function unit testing"){
    	parkLot.leave(1)
    	assert(parkLot.messages(0).toLowerCase contains "sorry, parking lot is not created")
    	parkLot.createParkingLot(3)
    	parkLot.park("KA-01-HH-1234","White")
    	parkLot.park("KA-01-HH-9999", "White")
    	parkLot.leave(1)
    	assert(parkLot.messages(4).toLowerCase contains "slot number 1 is free")
    	parkLot.leave(3)
    	assert(parkLot.messages(5).toLowerCase contains "slot number 3 is already empty")
    }

    test("status function unit testing"){
    	parkLot.leave(1)
    	assert(parkLot.messages(0).toLowerCase contains "sorry, parking lot is not created")
    	parkLot.createParkingLot(3)
    	parkLot.park("KA-01-HH-1234","White")
    	parkLot.park("KA-01-HH-9999", "White")
    	parkLot.status()
    	assert(parkLot.messages(4).toLowerCase contains "slot no.	registration no.	color")
    	assert(parkLot.messages(5).toLowerCase contains "1	ka-01-hh-1234	white")
    	assert(parkLot.messages(6).toLowerCase contains "2	ka-01-hh-9999	white")
    }	

    test("getRegistrationNumberFromColor function unit testing"){
    	parkLot.leave(1)
    	assert(parkLot.messages(0).toLowerCase contains "sorry, parking lot is not created")
    	parkLot.createParkingLot(3)
    	parkLot.park("KA-01-HH-1234","White")
    	parkLot.park("KA-01-HH-9999", "White")
    	parkLot.getRegistrationNumberFromColor("White")
    	assert(parkLot.messages(4).toLowerCase contains "ka-01-hh-1234, ka-01-hh-9999")
    	parkLot.getRegistrationNumberFromColor("Black")
    	assert(parkLot.messages(5).toLowerCase contains "not found")
    }

    test("getSlotNoFromColor function unit testing"){
    	parkLot.leave(1)
    	assert(parkLot.messages(0).toLowerCase contains "sorry, parking lot is not created")
    	parkLot.createParkingLot(3)
    	parkLot.park("KA-01-HH-1234","White")
    	parkLot.park("KA-01-HH-9999", "White")
    	parkLot.getSlotNoFromColor("White")
    	assert(parkLot.messages(4).toLowerCase contains "1, 2")
    	parkLot.getSlotNoFromColor("Black")
    	assert(parkLot.messages(5).toLowerCase contains "not found")
    }

    test("getSlotNoFromRegNo function unit testing"){
    	parkLot.leave(1)
    	assert(parkLot.messages(0).toLowerCase contains "sorry, parking lot is not created")
    	parkLot.createParkingLot(3)
    	parkLot.park("KA-01-HH-1234","White")
    	parkLot.park("KA-01-HH-9999", "KA-01-HH-1234")
    	parkLot.getSlotNoFromRegNo("KA-01-HH-1234")
    	assert(parkLot.messages(4).toLowerCase contains "1")
    	parkLot.getSlotNoFromRegNo("KA-01-HH-9997")
    	assert(parkLot.messages(5).toLowerCase contains "not found")
    }
}	
