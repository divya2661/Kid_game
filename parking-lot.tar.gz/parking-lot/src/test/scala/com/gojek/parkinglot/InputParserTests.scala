package com.gojek.parkinglot

import org.scalatest.FunSuite
import org.scalatest.BeforeAndAfter

class InputParserTests() extends FunSuite with BeforeAndAfter {
	
	var inputParser: InputParser = _

	before {
		inputParser = new InputParser
	}

	test("file parsing test"){
		val commdArray = inputParser.parseFileInput("input1.txt")
		assert(commdArray.length==0)	
		val commdArray1 = inputParser.parseFileInput(getClass.getClassLoader.getResource("input.txt").getPath)
		assert(commdArray1.length!=0)	
	}
}