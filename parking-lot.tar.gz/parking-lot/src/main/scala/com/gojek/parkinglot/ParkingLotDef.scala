package com.gojek.parkinglot

import scala.collection.mutable.{Map,ListBuffer}
import scala.util.Try
import com.gojek.parkinglot.LogCodes._

trait Output {
    def println(s: String) = Console.println(s)
    def print(s: String) = Console.print(s)
 }

class ParkingLotDef() extends Output {
	
	case class Car(regNo: String, color: String)		
	var slotCarMap = Map[Int, Car]()
	var availParkingSLot = ListBuffer[Int]()
	var maxCount = 0

	def getNearestEmptySlot(): Int = {
		for( slot <- 1 to availParkingSLot.length) {
			if(availParkingSLot(slot)==1) return slot
		}
		return -1;
	}

	def createParkingLot(numSlots: Int) {
		if(!Try(numSlots.toInt).isSuccess) {
			println(NUM_SLOT_ERROR) 
		}else {
			availParkingSLot =  ListBuffer.fill(numSlots+1)(1)
			maxCount = numSlots
			slotCarMap = Map[Int, Car]()
			println("Created parking lot with " + numSlots.toString + " slots")
		}
	}

	def park(regNo: String, color: String) {
		if(maxCount == 0){
			println(NO_PARKING_LOT_ERROR)
		} else if (slotCarMap.size == maxCount){
			println(PARKING_LOT_FULL_ERROR)
		} else {
			val nearestSlot = getNearestEmptySlot();
			val currCar = new Car(regNo, color)
			slotCarMap += (nearestSlot -> currCar)
			availParkingSLot(nearestSlot) = -1;
			println("Allocated slot number: " + nearestSlot.toString)
		}
	}

	def leave(slotNo: Int) {
		if(maxCount == 0) {
			println(NO_PARKING_LOT_ERROR)
		} else if(slotCarMap.size == 0){
			println(PARKING_LOT_EMPTY_ERROR)
		} else if(slotNo > maxCount || slotNo <= 0) {
			println(PARKING_LOT_OUT_OF_BOUND)
		} else if (!slotCarMap.contains(slotNo)) {
			println("Slot number " + slotNo.toString + " is already empty")
		} else {
			slotCarMap = slotCarMap - slotNo
			availParkingSLot(slotNo) = 1
			println("Slot number " + slotNo.toString + " is free")
		}
	}

	def status() {
		if(maxCount == 0) {
			println(NO_PARKING_LOT_ERROR)
		}else if(slotCarMap.size == 0){
			println(PARKING_LOT_EMPTY_ERROR)
		} else{
			println("Slot No.\tRegistration No.\tColor")

			for( (slot,car) <- slotCarMap.toSeq.sortBy(_._1)) {
				println(slot.toString + "\t" + car.regNo + "\t" + car.color)
			}
		}
	}

	def getRegistrationNumberFromColor(inputColor: String){
		if(maxCount == 0) {
			println(NO_PARKING_LOT_ERROR)
		}else if(slotCarMap.size == 0){
			println(PARKING_LOT_EMPTY_ERROR)
		} else{
			var tempMap = ListBuffer[Int]()
			var tempStr = ""
			for( (slot,car) <- slotCarMap.toSeq.sortBy(_._1)) {
				if(car.color == inputColor) tempMap += slot
			}
			if(tempMap.isEmpty) println("Not found")
			else {
				for( slot <- 0 until (tempMap.length - 1)){
					tempStr = tempStr + slotCarMap(tempMap(slot)).regNo + ", "
				}
				tempStr = tempStr + slotCarMap(tempMap(tempMap.length-1)).regNo
				println(tempStr)
			}
		}
	}

	def getSlotNoFromColor(inputColor: String){
		if(maxCount == 0) {
			println(NO_PARKING_LOT_ERROR)
		}else if(slotCarMap.size == 0){
			println(PARKING_LOT_EMPTY_ERROR)
		} else{
			var tempMap = ListBuffer[Int]()	
			var tempStr = ""
			for( (slot,car) <- slotCarMap.toSeq.sortBy(_._1)) {
				if(car.color == inputColor) tempMap += slot
			}
			if(tempMap.isEmpty) println("Not found")
			else {
				for( slot <- 0 until (tempMap.length - 1)){
					tempStr = tempStr + tempMap(slot).toString + ", "
				}
				tempStr = tempStr + tempMap(tempMap.length-1).toString
				println(tempStr)
			}
		}
	}

	def getSlotNoFromRegNo(inputRegNo: String){
		if (maxCount == 0) {
			println(NO_PARKING_LOT_ERROR)
		} else if (slotCarMap.size == 0){
			println(PARKING_LOT_EMPTY_ERROR)
		} else{
			for( (slot,car) <- slotCarMap.toSeq.sortBy(_._1)) {
				if(car.regNo == inputRegNo) {
					println(slot.toString) 
					return
				}	
			}
			println("Not found")	
		}
	}
}