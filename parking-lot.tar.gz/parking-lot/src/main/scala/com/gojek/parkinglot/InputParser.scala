package com.gojek.parkinglot

import scala.collection.mutable.{Map,ListBuffer}
import scala.util.Try

class InputParser{
	
	def parseFileInput(inputPath: String): Array[String] = {
		var commandArray = Array[String]()
		if(Try(scala.io.Source.fromFile(inputPath)).isSuccess){
			val source = scala.io.Source.fromFile(inputPath)
			val lines = source.getLines
			lines.foreach(x => (commandArray = commandArray :+ x))
		}else{
			println("Invalid file path, Please give a valid path")
		}
		return commandArray
	}
}