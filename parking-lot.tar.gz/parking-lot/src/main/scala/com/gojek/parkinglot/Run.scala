package com.gojek.parkinglot

import scala.io.StdIn.{readLine,readInt}

object Run {
	def main(args: Array[String]){
		val inputHandler = new InputHandler
		if(args.isEmpty){
			while(true){
		      	val inputLine = readLine()
		      	inputHandler.handler(inputLine.split(" "))
	    	}
		}else{
			val inputParser = new InputParser
			val commandArray = inputParser.parseFileInput(args(0))
			for( command <- commandArray) {
				inputHandler.handler(command.split(" "))	
			}
		}		
	}
}